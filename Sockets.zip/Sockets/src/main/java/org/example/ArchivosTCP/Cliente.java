package org.example.ArchivosTCP;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;

public class Cliente extends JFrame implements ActionListener {

    static final String SERVER_IP = "localhost";
    static final int SERVER_PUERTO = 12345; //puerto al que nos vamos a conectar
    Socket socket; //socket para la conexión con el server
    //defino ya los tipos de dato que manejaré para no tener que hacerlo todo el rato en los metodos
    DataInputStream dis;
    DataOutputStream dos;
    JTextArea textArea = new JTextArea(); //donde voy a mostrar los mensajes
    JTextField mensaje = new JTextField(); //el campo de texto para escribir los ficheros que quiero subir o bajar
    //los botones para realizar las acciones
    JButton subir = new JButton("Subir");
    JButton descargar = new JButton("Descargar");
    JButton salir = new JButton("Salir");

    /**
     * vuelvo a configurar la interfaz en el constructor
     * y me conecto al server, si todo sale bien muestra un mensaje en cosola y sino salta una excepcion
     */

    public Cliente() {
        setLayout(null);
        textArea.setBounds(10, 10, 400, 300);
        add(new JScrollPane(textArea));
        mensaje.setBounds(10, 320, 400, 30);
        add(mensaje);
        subir.setBounds(420, 10, 100, 30);
        add(subir);
        descargar.setBounds(420, 50, 100, 30);
        add(descargar);
        salir.setBounds(420, 90, 100, 30);
        add(salir);
        subir.addActionListener(this);
        descargar.addActionListener(this);
        salir.addActionListener(this);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setSize(540, 400);
        setVisible(true);
        setTitle("Cliente");
        try {
            socket = new Socket(SERVER_IP, SERVER_PUERTO);
            dis = new DataInputStream(socket.getInputStream());
            dos = new DataOutputStream(socket.getOutputStream());

            System.out.println("Conectado al servidor");
        } catch (IOException e) {
            System.out.println("Error al conectar con el servidor: " + e.getMessage());
            e.printStackTrace();
        }

    }

    /**
     * si le doy a subir cojo la ruta del archivo que voy a subir y llamo al metodo subirRuta para subir el archivo
     * si pincho descargar pillo el nombre del archivo y llamo al metodo descargarArchivo para descargarlo
     * y si presiono salir, la app se cierra
     * @param e the event to be processed
     */

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == subir){
            String ruta = "subidas/"+mensaje.getText();
            subirArchivo(ruta);
        }else if(e.getSource() == descargar){
            String nomFich = mensaje.getText();
            descargarArchivo(nomFich);
        }else if(e.getSource() == salir){
            try{
                dos.writeUTF("SALIR");
                socket.close();
                System.exit(0);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * paso por parametros el nombre del archivo que es el que indicaré en el cuadro de texto de la interfaz,
     * si el archivo existe recibo el fichero y lo guardo en la carpeta suya, que sería subidas
     * @param nomFich
     */

    void descargarArchivo(String nomFich) {
        try{
            dos.writeUTF("DESCARGAR");
            dos.writeUTF(nomFich);

            String respuesta = dis.readUTF();
            if(respuesta.equals("EXISTE")){
                long tamano = dis.readLong();

                FileOutputStream fos = new FileOutputStream(nomFich);
                byte[] buffer = new byte[1024];
                int leerBytes;
                long totalLeido = 0;
                while(totalLeido < tamano && (leerBytes = dis.read(buffer)) != -1){
                    fos.write(buffer, 0, leerBytes);
                    totalLeido += leerBytes;
                }
                fos.close();
                System.out.println("Archivo descargado "+nomFich);
            }else {
                System.out.println("No se encontro archivo");
            }
        }catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * paso la ruta donde el cliente tiene guardados los archivos y verifico que existe el archivo especificado,
     * si existe lo envio en bloques de 1024 bytes al server
     * una vez enviado el archivo muestro la confirmación de que se ha subido
     * @param ruta
     */

    void subirArchivo(String ruta){
        File archivo = new File(ruta);
        if(archivo.exists()){
            try{
                dos.writeUTF("SUBIR");
                dos.writeUTF(archivo.getName()); //envio el nombre
                dos.writeLong(archivo.length()); //envio el tamaño

                FileInputStream fis = new FileInputStream(archivo);
                byte[] buffer = new byte[1024];
                int leerBytes;
                long totalEnviado = 0;
                while ((leerBytes = fis.read(buffer)) != -1) {
                    dos.write(buffer, 0, leerBytes);
                    totalEnviado += leerBytes;
                }
                fis.close();
                dos.flush();
                System.out.println("Se ha subido el archivo "+archivo.getName());
            }catch (IOException e){
                e.printStackTrace();
            }
        }else{
            System.out.println("Archivo no encontrado");
        }
    }

    public static void main(String[] args) {
        Cliente c = new Cliente();
    }
}
