package org.example.ArchivosTCP;

import javax.swing.*;
import java.io.*;
import java.net.Socket;

public class HiloServidor extends Thread {

    private Socket socket; //conexión del cliente y el server

    public HiloServidor(Socket socket) {
        this.socket = socket;
    }

    /**
     * lee todo el rato si el cliente ha pulsado subir o descargar
     * si pulsa subir llama al metodo recibir y guardo el archivo
     * si pulsa descargar llama a enviar para pasarle el archivo al cliente
     * y si se pulsa salir la app termina
     */

    @Override
    public void run() {
        try(DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());){

            while(true){
                String opcion = in.readUTF();
                if(opcion.equals("SUBIR")){
                    recibir(in);
                }else if (opcion.equals("DESCARGAR")) {
                    enviar(in, out);
                }else if (opcion.equals("SALIR")) {
                    break;
                }
            }
        }catch (IOException e){
            e.printStackTrace();
        }finally {
            try {
                socket.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * reibo el archivo que va a subir el cliente y obtengo su nombre y tamaño
     * y lo guardo en el directorio especificado en el servidor en bloques de 1024 bytes
     * @param inputStream
     * @throws IOException
     */

    void recibir(DataInputStream inputStream) throws IOException {
        String nomFich = inputStream.readUTF();
        long tamano = inputStream.readLong(); //leo el tamaño del archivo

        File file = new File(Servidor.DIRECTORIO + nomFich); //me aseguro de que se guarde en el directorio correcto
        FileOutputStream fos = new FileOutputStream(file); //subo el fichero al servidor
        byte[] buffer = new byte[1024]; //leer datos en bloques grandes es mejor para la eficiencia que leer byte a byte
        int leerBytes;
        long totalLeido = 0;
        while(totalLeido < tamano && (leerBytes = inputStream.read(buffer)) != -1 ){ //leo el archivo en bloques de 1024 bytes
            fos.write(buffer, 0, leerBytes); //escribo los bytes leidos en el archivo del servidor
            totalLeido += leerBytes; //continuo el bucle hasta que haya leido todos los bytes
        }
        fos.close();
        //me aseguro de que el mensaje se actualice en la interfaz
        System.out.println("Se ha recibido el archivo "+nomFich);
    }

    /**
     * primero verifico si existe el archivo en el servidor y si este existe se lo envio al cliente en 1024 bytes
     * y si no existe se lo indico
     * @param inputStream
     * @param outputStream
     * @throws IOException
     */

    void enviar(DataInputStream inputStream, DataOutputStream outputStream) throws IOException {
        String nomFich = inputStream.readUTF();
        File archivo = new File(Servidor.DIRECTORIO + nomFich);
        if(archivo.exists()) {
            outputStream.writeUTF("EXISTE"); //informo al clienete de que existe el archivo
            outputStream.writeLong(archivo.length()); //envio el tamaño del archivo

            FileInputStream fis = new FileInputStream(archivo);
            byte[] buffer = new byte[1024];
            int leerBytes;
            while ((leerBytes = fis.read(buffer)) != -1) { //leo el archivo del server en bloques de bytes
                outputStream.write(buffer, 0, leerBytes); //escribo los bloques en el flujo de salida enviandoselos al cliente
                //continuo hasta leer todos los bytes
            }
            fis.close();
        }else{
            outputStream.writeUTF("INEXISTENTE");
        }
    }
}
