package org.example.ArchivosTCP;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor extends JFrame implements ActionListener {

    static final int PUERTO = 12345;
    static final String DIRECTORIO = "directorio/"; //en esta carpeta es donde va a subir y descargar los archivos el cliente
    static ServerSocket servidor;
    //los mensajes no funcionan al sacarlos por la ventana grafica asi que los estoy sacando por consola
    static JTextArea textArea = new JTextArea(); //esto es para que los mensajes en vez de salir por consola salgan por la ventana grafica
    JButton salir = new JButton("Salir");

    /**
     * en el constructor lo que hacemos es indicar el tamaño de la ventana donde mostraremos los mensajes
     * y configuramos también el botón de salir
     */

    public Servidor() {
        setLayout(null);
        textArea.setBounds(10, 10, 400, 300);
        add(new JScrollPane(textArea));
        salir.setBounds(420, 10, 100, 30);
        add(salir);
        salir.addActionListener(this);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setSize(540, 400);
        setVisible(true);
        setTitle("Servidor");
    }

    /**
     * este metodo va a manejar los botones de la ventana grafica
     * si pulsamos salir la app parará
     * @param e the event to be processed
     */

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == salir) {
            try {
                servidor.close();
                System.exit(0);
            } catch (IOException el) {
                el.printStackTrace();
            }
        }
    }

    /**
     * en el main inicializo el servidor en el puerto indicado, el 12345
     * si el directorio donde vamos a subir o bajar los archivos no existe lo creará
     * y creo un hilo para controlar a cada cliente que se conecte
     * @param args
     * @throws IOException
     */

    public static void main(String[] args) throws IOException {
        servidor = new ServerSocket(PUERTO);
        System.out.println("Servidor conectado");
        File file = new File(DIRECTORIO);
        if(!file.exists()) {
            file.mkdir();
        }
        Servidor server = new Servidor();
        while (true) {
            System.out.println("Esperando a que el cliente se conecte...");
            Socket socketCliente = servidor.accept();
            System.out.println("El cliente se ha conectado");

            //inicio un hilo para el cliente
            HiloServidor h = new HiloServidor(socketCliente);
            h.start();
        }

    }

}
